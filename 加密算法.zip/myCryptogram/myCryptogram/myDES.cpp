
#include "MyCryptogramHead.h"


//��ʼ���ݣ�
//IP���û���
BYTE	coorIP[2][64] =		{ 
								58 , 50 , 42 , 34 , 26 , 18 , 10 , 2  , 
								60 , 52 , 44 , 36 , 28 , 20 , 12 , 4  ,
								62 , 54 , 46 , 38 , 30 , 22 , 14 , 6  ,
								64 , 56 , 48 , 40 , 32 , 24 , 16 , 8  ,
								57 , 49 , 41 , 33 , 25 , 17 , 9  , 1  ,
								59 , 51 , 43 , 35 , 27 , 19 , 11 , 3  ,
								61 , 53 , 45 , 37 , 29 , 21 , 13 , 5  , 
								63 , 55 , 47 , 39 , 31 , 23 , 15 , 7  ,
								40 , 8  , 48 , 16 , 56 , 24 , 64 , 32 ,
								39 , 7  , 47 , 15 , 55 , 23 , 63 , 31 ,
								38 , 6  , 46 , 14 , 54 , 22 , 62 , 30 ,
								37 , 5  , 45 , 13 , 53 , 21 , 61 , 29 ,
								36 , 4  , 44 , 12 , 52 , 20 , 60 , 28 ,
								35 , 3  , 43 , 11 , 51 , 19 , 59 , 27 ,
								34 , 2  , 42 , 10 , 50 , 18 , 58 , 26 ,
								33 , 1  , 41 , 9  , 49 , 17 , 57 , 25
							};
//PC-1���û�
BYTE	coorPC1_C[28] =		{
								57 , 49 , 41 , 33 , 25 , 17 , 9  , 1  , 58 , 50 , 42 , 34 , 26 , 18 ,
								10 , 2  , 59 , 51 , 43 , 35 , 27 , 19 , 11 , 3  , 60 , 52 , 44 , 36 ,
							};

BYTE	coorPC1_D[28] =		{	
								63 , 55 , 47 , 39 , 31 , 23 , 15 , 7  , 62 , 54 , 46 , 38 , 30 , 22 ,
								14 , 6  , 61 , 53 , 45 , 37 , 29 , 21 , 13 , 5  , 28 , 20 , 12 , 4 
							};	
//PC-2���û�
BYTE	coorPC2[48] =		{
								14 , 17 , 11 , 24 , 1  , 5  , 3  , 28 , 15 , 6  , 21 , 10 ,
								23 , 19 , 12 , 4  , 26 , 8  , 16 , 7  , 27 , 20 , 13 , 2  ,
								41 , 52 , 31 , 37 , 47 , 55 , 30 , 40 , 51 , 45 , 33 , 48 ,
								44 , 49 , 39 , 56 , 34 , 53 , 46 , 42 , 50 , 36 , 29 , 32
							};
//��Ϊ������
BYTE	nummove[16] =		{
								1  , 1  , 2  , 2  , 2  , 2  , 2  , 2  , 1  , 2  , 2  , 2  , 2  , 2  , 2  , 1
							};
//bit�����
BYTE	changebit[16] =		{
								0  , 8  , 4  , 12 , 2  , 10 , 6  , 14 , 1  , 9  , 5  , 13 , 3  , 11 , 7  , 15
							};
//��չ�㷨���û���
BYTE	cooExpand[48] =		{
								32 , 1  , 2  , 3  , 4  , 5  , 4  , 5  , 6  , 7  , 8  , 9  ,
								8  , 9  , 10 , 11 , 12 , 13 , 12 , 13 , 14 , 15 , 16 , 17 ,
								16 , 17 , 18 , 19 , 20 , 21 , 20 , 21 , 22 , 23 , 24 , 25 ,
								24 , 25 , 26 , 27 , 28 , 29 , 28 , 29 , 30 , 31 , 32 , 1
							};
//SС�е��û������
BYTE	 boxS[8][4][16]=	{
								//S��1 
								{  
									14,4,13,1,2,15,11,8,3,10,6,12,5,9,0,7,
									0,15,7,4,14,2,13,1,10,6,12,11,9,5,3,8,
									4,1,14,8,13,6,2,11,15,12,9,7,3,10,5,0,
									15,12,8,2,4,9,1,7,5,11,3,14,10,0,6,13	
								},
								//S��2
								{
									15,1,8,14,6,11,3,4,9,7,2,13,12,0,5,10,
									3,13,4,7,15,2,8,14,12,0,1,10,6,9,11,5,
									0,14,7,11,10,4,13,1,5,8,12,6,9,3,2,15,
									13,8,10,1,3,15,4,2,11,6,7,12,0,5,14,9	
								},
								//S��3
								{
									10,0,9,14,6,3,15,5,1,13,12,7,11,4,2,8,
									13,7,0,9,3,4,6,10,2,8,5,14,12,11,15,1,
									13,6,4,9,8,15,3,0,11,1,2,12,5,10,14,7,
									1,10,13,0,6,9,8,7,4,15,14,3,11,5,2,12	
								},
								//S��4
								{
    								7,13,14,3,0,6,9,10,1,2,8,5,11,12,4,15,
									13,8,11,5,6,15,0,3,4,7,2,12,1,10,14,9,
									10,6,9,0,12,11,7,13,15,1,3,14,5,2,8,4,
									3,15,0,6,10,1,13,8,9,4,5,11,12,7,2,14
								},
								//S��5
								{ 
									2,12,4,1,7,10,11,6,8,5,3,15,13,0,14,9,
									14,11,2,12,4,7,13,1,5,0,15,10,3,9,8,6,
									4,2,1,11,10,13,7,8,15,9,12,5,6,3,0,14,
									11,8,12,7,1,14,2,13,6,15,0,9,10,4,5,3	
								},
								//S��6
								{
									12,1,10,15,9,2,6,8,0,13,3,4,14,7,5,11,
									10,15,4,2,7,12,9,5,6,1,13,14,0,11,3,8,
									9,14,15,5,2,8,12,3,7,0,4,10,1,13,11,6,
									4,3,2,12,9,5,15,10,11,14,1,7,6,0,8,13	
								},
								//S��7
								{
									4,11,2,14,15,0,8,13,3,12,9,7,5,10,6,1,
									13,0,11,7,4,9,1,10,14,3,5,12,2,15,8,6,
									1,4,11,13,12,3,7,14,10,15,6,8,0,5,9,2,
									6,11,13,8,1,4,10,7,9,5,0,15,14,2,3,12	
								},
								//S��8
								{
									13,2,8,4,6,15,11,1,10,9,3,14,5,0,12,7,
									1,15,13,8,10,3,7,4,12,5,6,11,0,14,9,2,
									7,11,4,1,9,12,14,2,0,6,10,13,15,3,5,8,
									2,1,14,7,4,10,8,13,15,12,9,0,3,5,6,11	
								}
						};
//P���û���
BYTE	cooP[32] =		{
							16 , 7  , 20 , 21 , 29 , 12 , 28 , 17 , 1  , 15 , 23 , 26 , 5  , 18 , 31 , 10 ,
							2  , 8  , 24 , 14 , 32 , 27 , 3  , 9  , 19 , 13 , 30 , 6  , 22 , 11 , 4  , 25	
						};
//����Ĵ���
union	THEregister
		{
			DWORD	byte4	;
			BYTE	byte1[4];		
		};


//�û���data1��64bits�û������data2
//���ܣ���function=0ʱΪIP�û�����function=1ʱΪIP�����û�
void	myDES_IniPermutation( BYTE *	data1 , BYTE *	data2 , BYTE function )
{
	memset( data2 , 0 , 8 * sizeof( BYTE ) ) ;
	BYTE	 i , CloseCode , Code ;
	for( i = 0 ; i < 64 ; i++ )
	{
		CloseCode		=	1 << ( ( coorIP[function][i] - 1 ) % 8 ) ;
		if( ( CloseCode & data1[( coorIP[function][i] - 1 ) / 8] ) == 0 )
			continue ;
		Code			=	1 << ( i % 8 ) ;
		data2[i / 8]	|=	Code ;	
	}
	return ;
}

//����Կ������
void	myDES_ProduceKey( BYTE * Key , BYTE KeyN[16][8] )
{
	THEregister		registerC , registerD ;
	BYTE			i , i2 , CloseCode , Code , circle ,
					midkey56[7];
	registerC.byte4 = 0 ;
	registerD.byte4 = 0 ;
	for( i = 0 ; i < 16 ; i++ )
		memset( KeyN[i] , 0 , 8 * sizeof( BYTE ) ) ;
	//PC-1 C�Ĵ����ĳ�ʼ��
	for( i = 0 ; i < 28 ; i++ )
	{
		CloseCode				=	1 << ( ( coorPC1_C[i] - 1 ) % 8 ) ;
		if( ( CloseCode & Key[( coorPC1_C[i] - 1 ) / 8] ) == 0 )
			continue ;
		Code					=	1 << ( i % 8 ) ;
		registerC.byte1[i / 8]	|=	Code ;	
	}
	//PC-1 D�Ĵ����ĳ�ʼ��
	for( i = 0 ; i < 28 ; i++ )
	{
		CloseCode				=	1 << ( ( coorPC1_D[i] - 1 ) % 8 ) ;
		if( ( CloseCode & Key[( coorPC1_D[i] - 1 ) / 8] ) == 0 )
			continue ;
		Code					=	1 << ( i % 8 ) ;
		registerD.byte1[i / 8]	|=	Code ;	
	}
	//����ѭ����PC-2��������Կ
	for( i = 0 ; i < 16 ; i++ )
	{
		//ѭ��
		for( circle = 0 ; circle < nummove[i] ; circle++ )
		{
			//C�Ĵ���
			Code				=	1 ;
			Code				&=	registerC.byte1[0] ;
			Code				<<=	3 ;
			registerC.byte4		>>=	1 ;				//���ڴ��д��Ϊ�������Խ�������
			registerC.byte1[3]	|=	Code ;

			//D�Ĵ���
			Code				=	1 ;
			Code				&=	registerD.byte1[0] ;
			Code				<<=	3 ;
			registerD.byte4		>>=	1 ;				
			registerD.byte1[3]	|=	Code ;
		}
		//��C��D�Ĵ����ϲ�����midkey56
		memset( midkey56 , 0 , 7 * sizeof( BYTE ) ) ;
		memcpy( midkey56 , registerC.byte1 , 4 * sizeof( BYTE ) ) ;
		CloseCode			=	15 ;
		Code				=	CloseCode & registerD.byte1[0] ;
		Code				<<=	4 ;
		midkey56[3]			|=	Code ;
		registerD.byte4		>>=	4 ;
		memcpy( midkey56 + 4 , registerD.byte1 , 3 * sizeof( BYTE ) ) ;

		//PC-2����
		for( i2 = 0 ; i2 < 48 ; i2++ )
		{
			CloseCode				=	1 << ( ( coorPC2[i2] - 1 ) % 8 ) ;
			if( ( CloseCode & midkey56[( coorPC2[i2] - 1 ) / 8] ) == 0 )
				continue ;
			Code					=	1 << ( i2 % 6 ) ;
			//������Կ����ÿ6bitһ���ֽڵķ�ʽ���
			KeyN[i][i2 / 6]	|=	Code ;	
		}
	}
	return ;
}

//��thestr�е�bit����С�˱�ʾ����newstr
void	myDES_myChange( BYTE thestr[8] , BYTE newstr[8] )
{
	memset( newstr , 0 , 8 * sizeof( BYTE ) ) ;
	BYTE	themid , i ;
	for( i = 0 ; i < 8 ; i++ )
	{
		themid		=	0 ;
		themid		|=	( changebit[ (thestr[i] & 0x0f) ] << 4 ) ;
		themid		|=	changebit[ ((thestr[i] & 0xf0) >> 4) ]  ;
		newstr[i]	=	themid ;
	}
	return ;
}

//��32λ������չ��48λ������ÿ��λ���һ���ֽ�
void	myDES_expand( BYTE data32[4] , BYTE data48[8] )
{
	memset( data48 , 0 , 8 * sizeof( BYTE ) ) ;
	BYTE	CloseCode , i , Code ;
	for( i = 0 ; i < 48 ; i++ )
	{
		CloseCode		=	1 << ( ( cooExpand[i] - 1 ) % 8 ) ;
		if( ( CloseCode & data32[( cooExpand[i] - 1 ) / 8] ) == 0 )
			continue ;
		Code			=	1 << ( i % 6 ) ;
		data48[i / 6]	|=	Code ;	
	}
	return ;
}

//f����
void	myDES_myF	( BYTE data[4] , BYTE newdata[4] , BYTE theKey[8] )
{
	
	BYTE	Edata[8] , middata[4] ,
			i , CloseCode , Code ;
	memset( newdata , 0 , 4 * sizeof( BYTE ) ) ;
	memset( Edata	, 0 , 8 * sizeof( BYTE ) ) ;
	memset( middata , 0 , 4 * sizeof( BYTE ) ) ;
	myDES_expand( data , Edata ) ;
	for( i = 0 ; i < 8 ; i += 2 )
	{
		middata[i / 2]	|=	myDES_myboxS( Edata[i] ^ theKey[i] , i ) ;
		middata[i / 2]	|=	( myDES_myboxS( Edata[i + 1] ^ theKey[i + 1] , i + 1 ) << 4 ) ;
	}

	for( i = 0 ; i < 32 ; i++ )
	{
		CloseCode		=	1 << ( ( cooP[i] - 1 ) % 8 ) ;
		if( ( CloseCode & middata[( cooP[i] - 1 ) / 8] ) == 0 )
			continue ;
		Code			=	1 << ( i % 8 ) ;
		newdata[i / 8]	|=	Code ;	
	}

	return ;
}

//�����No��������data6��Ӧ�����ֵ
BYTE	myDES_myboxS( BYTE data6 , BYTE No )
{
	BYTE	m(0) , n(0) ;
	if( data6 & 1 )			m += 1 << 1 ;
	if( data6 & (1 << 1) )	n += 1 << 3 ;
	if( data6 & (1 << 2) )	n += 1 << 2 ;
	if( data6 & (1 << 3) )	n += 1 << 1 ;
	if( data6 & (1 << 4) )	n += 1 ;
	if( data6 & (1 << 5) )	m += 1 ;
	return ( changebit[ boxS[No][m][n] ] ) ;
}
//---------------------------------------------------------------------//

//��64λ���ݽ��м�����ԿΪKey,�������code
void	myDES_encrypt64( BYTE message[8] , BYTE Key[8] , BYTE code[8] )
{
	BYTE	IPm[8] , L[4] , R[4] , KeyN[16][8] , myKey[8] , midld[4] , i ;

	memset( IPm		, 0 , 8 * sizeof( BYTE ) ) ;
	memset( L		, 0 , 4 * sizeof( BYTE ) ) ;
	memset( R		, 0 , 4 * sizeof( BYTE ) ) ;
	memset( midld	, 0 , 4 * sizeof( BYTE ) ) ;
	memset( KeyN	, 0 , 16 * 8 * sizeof( BYTE ) ) ;

	myDES_IniPermutation( message , IPm , 0 ) ;
	memcpy( L , IPm	+ 4	, 4 * sizeof( BYTE ) ) ;
	memcpy( R , IPm		, 4 * sizeof( BYTE ) ) ;

	myDES_myChange( Key , myKey );
	myDES_ProduceKey( myKey , KeyN ) ;

	for( i = 0 ; i < 16 ; i++ )
	{
		memcpy( midld , L , 4 * sizeof( BYTE ) ) ;
		myDES_myF( R , L , KeyN[i] ) ;
		*( DWORD * )midld	^=	*( DWORD * )L ;
		if( i != 15 )
		{
			memcpy( L , R		, 4 * sizeof( BYTE ) ) ;
			memcpy( R , midld	, 4 * sizeof( BYTE ) ) ;
		}
		else
			memcpy( L , midld	, 4 * sizeof( BYTE ) ) ;
	}

	memcpy( IPm	+ 4	, L	, 4 * sizeof( BYTE ) ) ;
	memcpy( IPm		, R	, 4 * sizeof( BYTE ) ) ;

	myDES_IniPermutation( IPm , code , 1 ) ;
	return ;
}

//��code���н������㣬��ԿΪKey���������message
void	myDES_decrypt64( BYTE code[8] , BYTE Key[8] , BYTE message[8] )
{
	BYTE	IPm[8] , L[4] , R[4] , KeyN[16][8] , myKey[8] , midld[4] , i ;

	memset( IPm		, 0 , 8 * sizeof( BYTE ) ) ;
	memset( L		, 0 , 4 * sizeof( BYTE ) ) ;
	memset( R		, 0 , 4 * sizeof( BYTE ) ) ;
	memset( midld	, 0 , 4 * sizeof( BYTE ) ) ;
	memset( KeyN	, 0 , 16 * 8 * sizeof( BYTE ) ) ;

	myDES_IniPermutation( code , IPm , 0 ) ;
	memcpy( L , IPm	+ 4	, 4 * sizeof( BYTE ) ) ;
	memcpy( R , IPm		, 4 * sizeof( BYTE ) ) ;

	myDES_myChange( Key , myKey );
	myDES_ProduceKey( myKey , KeyN ) ;

	for( i = 0 ; i < 16 ; i++ )
	{
		memcpy( midld , L , 4 * sizeof( BYTE ) ) ;
		myDES_myF( R , L , KeyN[15 - i] ) ;
		*( DWORD * )midld	^=	*( DWORD * )L ;
		if( i != 15 )
		{
			memcpy( L , R		, 4 * sizeof( BYTE ) ) ;
			memcpy( R , midld	, 4 * sizeof( BYTE ) ) ;
		}
		else
			memcpy( L , midld	, 4 * sizeof( BYTE ) ) ;
	}

	memcpy( IPm	+ 4	, L	, 4 * sizeof( BYTE ) ) ;
	memcpy( IPm		, R	, 4 * sizeof( BYTE ) ) ;

	myDES_IniPermutation( IPm , message , 1 ) ;
	return ;
}
//-----------------------------------------------------------------------//
////////////////////////////////////////////////////////////////////////

//��Lendata��������message���м�������
void	myDES_MYencrypt		( BYTE * message , BYTE Key[8] , int Lenmessage , BYTE * code ) 
{
	BYTE	*	data ;
	int			Lendata , i ;
	Lendata = (( Lenmessage - 1 ) / 8) * 8 + 8 ;
	data	=	new	BYTE[Lendata] ;
//	code	=	new	BYTE[Lendata] ;
	memset( data , 0 , Lendata * sizeof( BYTE ) ) ;
	memset( code , 0 , Lendata * sizeof( BYTE ) ) ;
	memcpy( data , message , Lenmessage * sizeof( BYTE ) ) ;
	for( i = 0 ; i < Lendata ; i += 8 )
		myDES_encrypt64( data + i , Key , code + i ) ;

	delete	data ;
	return ;
}
//��Lendata��������code���н�������
void	myDES_MYdecrypt		( BYTE * code , BYTE Key[8] , int Lencode , BYTE * message ) 
{
	BYTE	*	data ;
	int			Lendata , i ;
	Lendata = (( Lencode - 1 ) / 8) * 8 + 8 ;
	data	=	new	BYTE[Lendata] ;
//	message	=	new	BYTE[Lendata] ;
	memset( data	, 0 , Lendata * sizeof( BYTE ) ) ;
	memset( message , 0 , Lendata * sizeof( BYTE ) ) ;
	memcpy( data , code , Lencode * sizeof( BYTE ) ) ;
	for( i = 0 ; i < Lendata ; i += 8 )
		myDES_decrypt64( data + i , Key , message + i ) ;
	delete	data ;
	return ;
}

/////////////////////////////////////////////////////////////
//ֱ�Ӹ���������Կ��ÿ�μ��ܲ���Ҫ���ظ�����������Կ
void	myDES_encrypt64_allKey( BYTE message[8] , BYTE KeyN[16][8] , BYTE code[8] ) 
{
	BYTE	IPm[8] , L[4] , R[4] , midld[4] , i ;

	memset( IPm		, 0 , 8 * sizeof( BYTE ) ) ;
	memset( L		, 0 , 4 * sizeof( BYTE ) ) ;
	memset( R		, 0 , 4 * sizeof( BYTE ) ) ;
	memset( midld	, 0 , 4 * sizeof( BYTE ) ) ;

	myDES_IniPermutation( message , IPm , 0 ) ;
	memcpy( L , IPm	+ 4	, 4 * sizeof( BYTE ) ) ;
	memcpy( R , IPm		, 4 * sizeof( BYTE ) ) ;

	for( i = 0 ; i < 16 ; i++ )
	{
		memcpy( midld , L , 4 * sizeof( BYTE ) ) ;
		myDES_myF( R , L , KeyN[i] ) ;
		*( DWORD * )midld	^=	*( DWORD * )L ;
		if( i != 15 )
		{
			memcpy( L , R		, 4 * sizeof( BYTE ) ) ;
			memcpy( R , midld	, 4 * sizeof( BYTE ) ) ;
		}
		else
			memcpy( L , midld	, 4 * sizeof( BYTE ) ) ;
	}

	memcpy( IPm	+ 4	, L	, 4 * sizeof( BYTE ) ) ;
	memcpy( IPm		, R	, 4 * sizeof( BYTE ) ) ;

	myDES_IniPermutation( IPm , code , 1 ) ;
	return ;
} 
void	myDES_decrypt64_allKey( BYTE code[8] , BYTE KeyN[16][8] , BYTE message[8] ) 
{
	BYTE	IPm[8] , L[4] , R[4] , midld[4] , i ;

	memset( IPm		, 0 , 8 * sizeof( BYTE ) ) ;
	memset( L		, 0 , 4 * sizeof( BYTE ) ) ;
	memset( R		, 0 , 4 * sizeof( BYTE ) ) ;
	memset( midld	, 0 , 4 * sizeof( BYTE ) ) ;

	myDES_IniPermutation( code , IPm , 0 ) ;
	memcpy( L , IPm	+ 4	, 4 * sizeof( BYTE ) ) ;
	memcpy( R , IPm		, 4 * sizeof( BYTE ) ) ;

	for( i = 0 ; i < 16 ; i++ )
	{
		memcpy( midld , L , 4 * sizeof( BYTE ) ) ;
		myDES_myF( R , L , KeyN[15 - i] ) ;
		*( DWORD * )midld	^=	*( DWORD * )L ;
		if( i != 15 )
		{
			memcpy( L , R		, 4 * sizeof( BYTE ) ) ;
			memcpy( R , midld	, 4 * sizeof( BYTE ) ) ;
		}
		else
			memcpy( L , midld	, 4 * sizeof( BYTE ) ) ;
	}

	memcpy( IPm	+ 4	, L	, 4 * sizeof( BYTE ) ) ;
	memcpy( IPm		, R	, 4 * sizeof( BYTE ) ) ;

	myDES_IniPermutation( IPm , message , 1 ) ;
	return ;
}

