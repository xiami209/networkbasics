#include "MyCryptogramHead.h"

void mySHA1_SubHASH(DWORD InputData[16],DWORD HashValue[5])
{
#define K1_sha1 0x5a827999
#define K2_sha1 0x6ed9eba1
#define K3_sha1 0x8f1bbcdc
#define K4_sha1 0xca62c1d6
//<<<����   x<<<n
#define SRL32_sha1(x,n) (((x)<<n)|((x)>>(32-n)))

#define F1_sha1_sha1(x,y,z) ((x&y)|((~x)&z))
#define F2_sha1(x,y,z) (x^y^z)
#define F3_sha1(x,y,z) ((x&y)|(x&z)|(y&z))
#define F4_sha1(x,y,z) (x^y^z)


	DWORD a,b,c,d,e,pM[80],TEMP=0,i;
	a=HashValue[0];
	b=HashValue[1];
	c=HashValue[2];
	d=HashValue[3];
	e=HashValue[4];

	memset((BYTE *)pM,0,sizeof(DWORD)*80);//��ʼ��
	for(i=0;i<80;i++)
	{
		if(i<16)
		{
			((BYTE *)pM)[i*4]=((BYTE *)InputData)[i*4+3];
			((BYTE *)pM)[i*4+1]=((BYTE *)InputData)[i*4+2];
			((BYTE *)pM)[i*4+2]=((BYTE *)InputData)[i*4+1];
			((BYTE *)pM)[i*4+3]=((BYTE *)InputData)[i*4];
			TEMP=SRL32_sha1(a,5)+F1_sha1_sha1(b,c,d)+e+pM[i]+K1_sha1;
			e=d;
			d=c;
			c=SRL32_sha1(b,30);
			b=a;
			a=TEMP;
			continue;
		}
		
		if(i<20)
		{
			pM[i]=SRL32_sha1(pM[i-3]^pM[i-8]^pM[i-14]^pM[i-16],1);
			TEMP=SRL32_sha1(a,5)+F1_sha1_sha1(b,c,d)+e+pM[i]+K1_sha1;
			e=d;
			d=c;
			c=SRL32_sha1(b,30);
			b=a;
			a=TEMP;
			continue;
		}
		
		if(i<40)
		{
			pM[i]=SRL32_sha1(pM[i-3]^pM[i-8]^pM[i-14]^pM[i-16],1);
			TEMP=SRL32_sha1(a,5)+F2_sha1(b,c,d)+e+pM[i]+K2_sha1;
			e=d;
			d=c;
			c=SRL32_sha1(b,30);
			b=a;
			a=TEMP;
			continue;
		}
		
		if(i<60)
		{
			pM[i]=SRL32_sha1(pM[i-3]^pM[i-8]^pM[i-14]^pM[i-16],1);
			TEMP=SRL32_sha1(a,5)+F3_sha1(b,c,d)+e+pM[i]+K3_sha1;
			e=d;
			d=c;
			c=SRL32_sha1(b,30);
			b=a;
			a=TEMP;
			continue;
		}
		
		if(i<80)
		{
			pM[i]=SRL32_sha1(pM[i-3]^pM[i-8]^pM[i-14]^pM[i-16],1);
			TEMP=SRL32_sha1(a,5)+F4_sha1(b,c,d)+e+pM[i]+K4_sha1;
			e=d;
			d=c;
			c=SRL32_sha1(b,30);
			b=a;
			a=TEMP;
		}
	}

  HashValue[0]+=a;
  HashValue[1]+=b;
  HashValue[2]+=c;
  HashValue[3]+=d;
  HashValue[4]+=e;
  return;
}

void mySHA1_Run( BYTE *InStr , unsigned _int64 LenData ,  DWORD OutInt[5] )
{
	OutInt[0]=0x67452301;
	OutInt[1]=0xEFCDAB89;
	OutInt[2]=0x98BADCFE;
	OutInt[3]=0x10325476;
	OutInt[4]=0xC3D2E1F0;

	unsigned _int64	TheLen( LenData ) , i(0) ;
	BYTE	Data64[64] = {0} ;

	while( TheLen >= 64 )
	{
		memcpy( Data64 , InStr + LenData - TheLen , 64 ) ;
		mySHA1_SubHASH( (DWORD *)Data64 , OutInt ) ;
		TheLen -= 64 ;
	}

	if( TheLen < 56 )
	{
		BYTE	LastData64[64] = {0} ;
		for( i = 0 ; i < TheLen ; i++ )
			LastData64[i] = InStr[LenData - TheLen + i] ;
		LastData64[ TheLen ] = 0x80 ;
		LastData64[56] = (BYTE)(LenData >> 53 ) ;
		LastData64[57] = (BYTE)(LenData >> 45 ) ;
		LastData64[58] = (BYTE)(LenData >> 37 ) ;
		LastData64[59] = (BYTE)(LenData >> 29 ) ;
		LastData64[60] = (BYTE)(LenData >> 21 ) ;
		LastData64[61] = (BYTE)(LenData >> 13 ) ;
		LastData64[62] = (BYTE)(LenData >> 5  ) ;
		LastData64[63] = (BYTE)(LenData << 3  ) ;
		mySHA1_SubHASH( (DWORD *)LastData64 , OutInt ) ;
	}
	else
	{
		BYTE	LastData128[128] = {0} ;
		for( i = 0 ; i < TheLen ; i++ )
			LastData128[i] = InStr[LenData - TheLen + i] ;
		LastData128[ TheLen ] = 0x80 ;
		LastData128[120] = (BYTE)(LenData >> 53 ) ;
		LastData128[121] = (BYTE)(LenData >> 45 ) ;
		LastData128[122] = (BYTE)(LenData >> 37 ) ;
		LastData128[123] = (BYTE)(LenData >> 29 ) ;
		LastData128[124] = (BYTE)(LenData >> 21 ) ;
		LastData128[125] = (BYTE)(LenData >> 13 ) ;
		LastData128[126] = (BYTE)(LenData >> 5  ) ;
		LastData128[127] = (BYTE)(LenData << 3  ) ;
		mySHA1_SubHASH( (DWORD *)LastData128		, OutInt ) ;
		mySHA1_SubHASH( (DWORD *)LastData128 + 16 , OutInt ) ;
	}

	return;

}

void mySHA1_RunStr( BYTE *InStr , unsigned _int64 LenData ,  char OutPutStr[40] )
{
	DWORD OutInt[5] ;
	mySHA1_Run(InStr,LenData,OutInt) ;
	for( BYTE i = 0 ; i < 5 ; i++ )
	{
		itoa( OutInt[i] >> 28 & 0xf , OutPutStr + i * 8 , 16 ) ;
		itoa( OutInt[i] >> 24 & 0xf , OutPutStr + i * 8 + 1 , 16 ) ;
		itoa( OutInt[i] >> 20 & 0xf , OutPutStr + i * 8 + 2 , 16 ) ;
		itoa( OutInt[i] >> 16 & 0xf , OutPutStr + i * 8 + 3 , 16 ) ;
		itoa( OutInt[i] >> 12 & 0xf , OutPutStr + i * 8 + 4 , 16 ) ;
		itoa( OutInt[i] >>  8 & 0xf , OutPutStr + i * 8 + 5 , 16 ) ;
		itoa( OutInt[i] >>  4 & 0xf , OutPutStr + i * 8 + 6 , 16 ) ;
		itoa( OutInt[i]		  & 0xf , OutPutStr + i * 8 + 7 , 16 ) ;
	}
	return ;
}