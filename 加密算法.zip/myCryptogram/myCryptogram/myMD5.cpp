#include "MyCryptogramHead.h"


#define F1(x,y,z) (z^(x&(y^z)))
#define F2(x,y,z) F1(z,x,y)
#define F3(x,y,z) (x^y^z)
#define F4(x,y,z) (y^(x|~z))

#define SRL32(x,n) (((x)<<n)|((x)>>(32-n)))

#define DOSTEP(f,w,x,y,z,data,s) w=SRL32(w+f(x,y,z)+data,s)+x

#define K1 0x5a827999
#define K2 0x6ed9eba1
#define K3 0x8f1bbcdc
#define K4 0xca62c1d6

#define H0_init 0x67452301 
#define H1_init 0xefcdab89 
#define H2_init 0x98badcfe 
#define H3_init 0x10325476 



void myMD5_SubHASH(DWORD InputData[16],DWORD HashValue[4])

{
	DWORD a,c,b,d,*pM=InputData;

	a=HashValue[0];
	b=HashValue[1];
	c=HashValue[2];
	d=HashValue[3];

  /****************************************************/
 //��һ��--------------------------------->
  DOSTEP(F1,a, b, c, d, pM[ 0]+0xd76aa478,7);
  DOSTEP(F1,d, a, b, c, pM[ 1]+0xe8c7b756,12); //- 2 -
  DOSTEP(F1,c, d, a, b, pM[ 2]+0x242070db,17); //- 3 -
  DOSTEP(F1,b, c, d, a, pM[ 3]+0xc1bdceee,22); //- 4 -
  DOSTEP(F1,a, b, c, d, pM[ 4]+0xf57c0faf,7); //- 5 -
  DOSTEP(F1,d, a, b, c, pM[ 5]+0x4787c62a,12); //- 6 -
  DOSTEP(F1,c, d, a, b, pM[ 6]+0xa8304613,17); //- 7 -
  DOSTEP(F1,b, c, d, a, pM[ 7]+0xfd469501,22); //- 8 -
  DOSTEP(F1,a, b, c, d, pM[ 8]+0x698098d8,7); //- 9 -
  DOSTEP(F1,d, a, b, c, pM[ 9]+0x8b44f7af,12); //- 10 -
  DOSTEP(F1,c, d, a, b, pM[10]+0xffff5bb1,17); //- 11 -
  DOSTEP(F1,b, c, d, a, pM[11]+0x895cd7be,22); //- 12 -
  DOSTEP(F1,a, b, c, d, pM[12]+0x6b901122,7); //- 13 -
  DOSTEP(F1,d, a, b, c, pM[13]+0xfd987193,12); //- 14 -
  DOSTEP(F1,c, d, a, b, pM[14]+0xa679438e,17); //- 15 -
  DOSTEP(F1,b, c, d, a, pM[15]+0x49b40821,22); //- 16 -

 //�ڶ���--------------------------------->
  DOSTEP(F2,a, b, c, d, pM[ 1]+0xf61e2562,5); //- 17 -
  DOSTEP(F2,d, a, b, c, pM[ 6]+0xc040b340,9); //- 18 -
  DOSTEP(F2,c, d, a, b, pM[11]+0x265e5a51,14); //- 19 -
  DOSTEP(F2,b, c, d, a, pM[ 0]+0xe9b6c7aa,20); //- 20 -
  DOSTEP(F2,a, b, c, d, pM[ 5]+0xd62f105d,5); //- 21 -
  DOSTEP(F2,d, a, b, c, pM[10]+0x02441453,9); //- 22 -
  DOSTEP(F2,c, d, a, b, pM[15]+0xd8a1e681,14); //- 23 -
  DOSTEP(F2,b, c, d, a, pM[ 4]+0xe7d3fbc8,20); //- 24 -
  DOSTEP(F2,a, b, c, d, pM[ 9]+0x21e1cde6,5); //- 25 -
  DOSTEP(F2,d, a, b, c, pM[14]+0xc33707d6,9); //- 26 -
  DOSTEP(F2,c, d, a, b, pM[ 3]+0xf4d50d87,14); //- 27 -
  DOSTEP(F2,b, c, d, a, pM[ 8]+0x455a14ed,20); //- 28 -
  DOSTEP(F2,a, b, c, d, pM[13]+0xa9e3e905,5); //- 29 -
  DOSTEP(F2,d, a, b, c, pM[ 2]+0xfcefa3f8,9); //- 30 -
  DOSTEP(F2,c, d, a, b, pM[ 7]+0x676f02d9,14); //- 31 -
  DOSTEP(F2,b, c, d, a, pM[12]+0x8d2a4c8a,20); //- 32 -

 //������--------------------------------->
  DOSTEP(F3,a, b, c, d, pM[ 5]+0xfffa3942,4); //- 33 -
  DOSTEP(F3,d, a, b, c, pM[ 8]+0x8771f681,11); //- 34 -
  DOSTEP(F3,c, d, a, b, pM[11]+0x6d9d6122,16); //- 35 -
  DOSTEP(F3,b, c, d, a, pM[14]+0xfde5380c,23); //- 36 -
  DOSTEP(F3,a, b, c, d, pM[ 1]+0xa4beea44,4); //- 37 -
  DOSTEP(F3,d, a, b, c, pM[ 4]+0x4bdecfa9,11); //- 38 -
  DOSTEP(F3,c, d, a, b, pM[ 7]+0xf6bb4b60,16); //- 39 -
  DOSTEP(F3,b, c, d, a, pM[10]+0xbebfbc70,23); //- 40 -
  DOSTEP(F3,a, b, c, d, pM[13]+0x289b7ec6,4); //- 41 -
  DOSTEP(F3,d, a, b, c, pM[ 0]+0xeaa127fa,11); //- 42 -
  DOSTEP(F3,c, d, a, b, pM[ 3]+0xd4ef3085,16); //- 43 -
  DOSTEP(F3,b, c, d, a, pM[ 6]+0x4881d05,23); //- 44 -
  DOSTEP(F3,a, b, c, d, pM[ 9]+0xd9d4d039,4); //- 45 -
  DOSTEP(F3,d, a, b, c, pM[12]+0xe6db99e5,11); //- 46 -
  DOSTEP(F3,c, d, a, b, pM[15]+0x1fa27cf8,16); //- 47 -
  DOSTEP(F3,b, c, d, a, pM[ 2]+0xc4ac5665,23); //- 48 -

  //������-------------------------------->
  DOSTEP(F4,a, b, c, d, pM[ 0]+0xf4292244,6); //- 49 -
  DOSTEP(F4,d, a, b, c, pM[ 7]+0x432aff97,10); //- 50 -
  DOSTEP(F4,c, d, a, b, pM[14]+0xab9423a7,15); //- 51 -
  DOSTEP(F4,b, c, d, a, pM[ 5]+0xfc93a039,21); //- 52 -
  DOSTEP(F4,a, b, c, d, pM[12]+0x655b59c3,6); //- 53 -
  DOSTEP(F4,d, a, b, c, pM[ 3]+0x8f0ccc92,10); //- 54 -
  DOSTEP(F4,c, d, a, b, pM[10]+0xffeff47d,15); //- 55 -
  DOSTEP(F4,b, c, d, a, pM[ 1]+0x85845dd1,21); //- 56 -
  DOSTEP(F4,a, b, c, d, pM[ 8]+0x6fa87e4f,6); //- 57 -
  DOSTEP(F4,d, a, b, c, pM[15]+0xfe2ce6e0,10); //- 58 -
  DOSTEP(F4,c, d, a, b, pM[ 6]+0xa3014314,15); //- 59 -
  DOSTEP(F4,b, c, d, a, pM[13]+0x4e0811a1,21); //- 60 -
  DOSTEP(F4,a, b, c, d, pM[ 4]+0xf7537e82,6); //- 61 -
  DOSTEP(F4,d, a, b, c, pM[11]+0xbd3af235,10); //- 62 -
  DOSTEP(F4,c, d, a, b, pM[ 2]+0x2ad7d2bb,15); //- 63 -
  DOSTEP(F4,b, c, d, a, pM[ 9]+0xeb86d391,21); //- 64 -
  /***************************************************/

  HashValue[0]+=a;
  HashValue[1]+=b;
  HashValue[2]+=c;
  HashValue[3]+=d;

  return;

}

void myMD5_Run( BYTE *InStr , unsigned _int64 LenData ,  DWORD OutInt[4] )
{
	OutInt[0]=0x67452301;
	OutInt[1]=0xefcdab89;
	OutInt[2]=0x98badcfe;
	OutInt[3]=0x10325476;

	unsigned _int64	TheLen( LenData ) , i(0) ;
	BYTE	Data64[64] = {0} ;

	while( TheLen >= 64 )
	{
		memcpy( Data64 , InStr + LenData - TheLen , 64 ) ;
		myMD5_SubHASH( (DWORD *)Data64 , OutInt ) ;
		TheLen -= 64 ;
	}

	if( TheLen < 56 )
	{
		BYTE	LastData64[64] = {0} ;
		for( i = 0 ; i < TheLen ; i++ )
			LastData64[i] = InStr[LenData - TheLen + i] ;
		LastData64[ TheLen ] = 0x80 ;
		((unsigned _int64 *)LastData64)[7] = ( LenData << 3 ) ;
		myMD5_SubHASH( (DWORD *)LastData64 , OutInt ) ;
	}
	else
	{
		BYTE	LastData128[128] = {0} ;
		for( i = 0 ; i < TheLen ; i++ )
			LastData128[i] = InStr[LenData - TheLen + i] ;
		LastData128[ TheLen ] = 0x80 ;
		((unsigned _int64 *)LastData128)[15] = ( LenData << 3 ) ;
		myMD5_SubHASH( (DWORD *)LastData128		, OutInt ) ;
		myMD5_SubHASH( (DWORD *)LastData128 + 16 , OutInt ) ;
	}

	return;
}

void myMD5_RunStr( BYTE *InStr , unsigned _int64 LenData ,  char OutPutStr[32] )
{
	DWORD OutInt[4] ;
	myMD5_Run(InStr,LenData,OutInt) ;
	for( BYTE i = 0 ; i < 16 ; i++ )
	{
		itoa( ((BYTE *)OutInt)[i] >> 4  , OutPutStr + i * 2 , 16 ) ;
		itoa( ((BYTE *)OutInt)[i] & 0xf , OutPutStr + i * 2 + 1 , 16 ) ;
	}
	return ;
}
