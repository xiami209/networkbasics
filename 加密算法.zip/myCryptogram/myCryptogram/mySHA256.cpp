#include "MyCryptogramHead.h"

void mySHA256_SubHASH(DWORD InputData[16],DWORD HashValue[8])
{

#define  SHR(x,n) ((x & 0xFFFFFFFF) >> n)
#define ROTR(x,n) (SHR(x,n) | (x << (32 - n)))

#define S0(x) (ROTR(x, 7) ^ ROTR(x,18) ^  SHR(x, 3))
#define S1(x) (ROTR(x,17) ^ ROTR(x,19) ^  SHR(x,10))

#define S2(x) (ROTR(x, 2) ^ ROTR(x,13) ^ ROTR(x,22))
#define S3(x) (ROTR(x, 6) ^ ROTR(x,11) ^ ROTR(x,25))

#define F0(x,y,z) ((x & y) | (z & (x | y)))
#define F1(x,y,z) (z ^ (x & (y ^ z)))

#define R(t)   (W[t] = S1(W[t -  2]) + W[t -  7] + S0(W[t - 15]) + W[t - 16])

#define P(a,b,c,d,e,f,g,h,x,K)                  \
{                                               \
    temp1 = h + S3(e) + F1(e,f,g) + K + x;      \
    temp2 = S2(a) + F0(a,b,c);                  \
    d += temp1;									\
	h = temp1 + temp2;							\
}


    DWORD temp1, temp2, W[64];
    DWORD A, B, C, D, E, F, G, H;
	for( DWORD i = 0 ; i < 16 ; i++ )
	{
		W[i] =		( (DWORD)((BYTE *)InputData)[i * 4] << 24 )        
				|	( (DWORD)((BYTE *)InputData)[i * 4 + 1] << 16 )        
				|	( (DWORD)((BYTE *)InputData)[i * 4 + 2] <<  8 )        
				|	( (DWORD)((BYTE *)InputData)[i * 4 + 3]       );       
	}

	A = HashValue[0];
    B = HashValue[1];
    C = HashValue[2];
    D = HashValue[3];
    E = HashValue[4];
    F = HashValue[5];
    G = HashValue[6];
    H = HashValue[7];

    P( A, B, C, D, E, F, G, H, W[ 0], 0x428A2F98 );
    P( H, A, B, C, D, E, F, G, W[ 1], 0x71374491 );
    P( G, H, A, B, C, D, E, F, W[ 2], 0xB5C0FBCF );
    P( F, G, H, A, B, C, D, E, W[ 3], 0xE9B5DBA5 );
    P( E, F, G, H, A, B, C, D, W[ 4], 0x3956C25B );
    P( D, E, F, G, H, A, B, C, W[ 5], 0x59F111F1 );
    P( C, D, E, F, G, H, A, B, W[ 6], 0x923F82A4 );
    P( B, C, D, E, F, G, H, A, W[ 7], 0xAB1C5ED5 );
    P( A, B, C, D, E, F, G, H, W[ 8], 0xD807AA98 );
    P( H, A, B, C, D, E, F, G, W[ 9], 0x12835B01 );
    P( G, H, A, B, C, D, E, F, W[10], 0x243185BE );
    P( F, G, H, A, B, C, D, E, W[11], 0x550C7DC3 );
    P( E, F, G, H, A, B, C, D, W[12], 0x72BE5D74 );
    P( D, E, F, G, H, A, B, C, W[13], 0x80DEB1FE );
    P( C, D, E, F, G, H, A, B, W[14], 0x9BDC06A7 );
    P( B, C, D, E, F, G, H, A, W[15], 0xC19BF174 );
    P( A, B, C, D, E, F, G, H, R(16), 0xE49B69C1 );
    P( H, A, B, C, D, E, F, G, R(17), 0xEFBE4786 );
    P( G, H, A, B, C, D, E, F, R(18), 0x0FC19DC6 );
    P( F, G, H, A, B, C, D, E, R(19), 0x240CA1CC );
    P( E, F, G, H, A, B, C, D, R(20), 0x2DE92C6F );
    P( D, E, F, G, H, A, B, C, R(21), 0x4A7484AA );
    P( C, D, E, F, G, H, A, B, R(22), 0x5CB0A9DC );
    P( B, C, D, E, F, G, H, A, R(23), 0x76F988DA );
    P( A, B, C, D, E, F, G, H, R(24), 0x983E5152 );
    P( H, A, B, C, D, E, F, G, R(25), 0xA831C66D );
    P( G, H, A, B, C, D, E, F, R(26), 0xB00327C8 );
    P( F, G, H, A, B, C, D, E, R(27), 0xBF597FC7 );
    P( E, F, G, H, A, B, C, D, R(28), 0xC6E00BF3 );
    P( D, E, F, G, H, A, B, C, R(29), 0xD5A79147 );
    P( C, D, E, F, G, H, A, B, R(30), 0x06CA6351 );
    P( B, C, D, E, F, G, H, A, R(31), 0x14292967 );
    P( A, B, C, D, E, F, G, H, R(32), 0x27B70A85 );
    P( H, A, B, C, D, E, F, G, R(33), 0x2E1B2138 );
    P( G, H, A, B, C, D, E, F, R(34), 0x4D2C6DFC );
    P( F, G, H, A, B, C, D, E, R(35), 0x53380D13 );
    P( E, F, G, H, A, B, C, D, R(36), 0x650A7354 );
    P( D, E, F, G, H, A, B, C, R(37), 0x766A0ABB );
    P( C, D, E, F, G, H, A, B, R(38), 0x81C2C92E );
    P( B, C, D, E, F, G, H, A, R(39), 0x92722C85 );
    P( A, B, C, D, E, F, G, H, R(40), 0xA2BFE8A1 );
    P( H, A, B, C, D, E, F, G, R(41), 0xA81A664B );
    P( G, H, A, B, C, D, E, F, R(42), 0xC24B8B70 );
    P( F, G, H, A, B, C, D, E, R(43), 0xC76C51A3 );
    P( E, F, G, H, A, B, C, D, R(44), 0xD192E819 );
    P( D, E, F, G, H, A, B, C, R(45), 0xD6990624 );
    P( C, D, E, F, G, H, A, B, R(46), 0xF40E3585 );
    P( B, C, D, E, F, G, H, A, R(47), 0x106AA070 );
    P( A, B, C, D, E, F, G, H, R(48), 0x19A4C116 );
    P( H, A, B, C, D, E, F, G, R(49), 0x1E376C08 );
    P( G, H, A, B, C, D, E, F, R(50), 0x2748774C );
    P( F, G, H, A, B, C, D, E, R(51), 0x34B0BCB5 );
    P( E, F, G, H, A, B, C, D, R(52), 0x391C0CB3 );
    P( D, E, F, G, H, A, B, C, R(53), 0x4ED8AA4A );
    P( C, D, E, F, G, H, A, B, R(54), 0x5B9CCA4F );
    P( B, C, D, E, F, G, H, A, R(55), 0x682E6FF3 );
    P( A, B, C, D, E, F, G, H, R(56), 0x748F82EE );
    P( H, A, B, C, D, E, F, G, R(57), 0x78A5636F );
    P( G, H, A, B, C, D, E, F, R(58), 0x84C87814 );
    P( F, G, H, A, B, C, D, E, R(59), 0x8CC70208 );
    P( E, F, G, H, A, B, C, D, R(60), 0x90BEFFFA );
    P( D, E, F, G, H, A, B, C, R(61), 0xA4506CEB );
    P( C, D, E, F, G, H, A, B, R(62), 0xBEF9A3F7 );
    P( B, C, D, E, F, G, H, A, R(63), 0xC67178F2 );

    HashValue[0] += A;
    HashValue[1] += B;
    HashValue[2] += C;
    HashValue[3] += D;
    HashValue[4] += E;
    HashValue[5] += F;
    HashValue[6] += G;
    HashValue[7] += H;
}

void mySHA256_Run( BYTE *InStr , unsigned _int64 LenData ,  DWORD OutInt[8] )
{
	OutInt[0] = 0x6A09E667;
	OutInt[1] = 0xBB67AE85;
	OutInt[2] = 0x3C6EF372;
	OutInt[3] = 0xA54FF53A;
	OutInt[4] = 0x510E527F;
	OutInt[5] = 0x9B05688C;
	OutInt[6] = 0x1F83D9AB;
	OutInt[7] = 0x5BE0CD19;

	unsigned _int64	TheLen( LenData ) , i(0) ;
	BYTE	Data64[64] = {0} ;

	while( TheLen >= 64 )
	{
		memcpy( Data64 , InStr + LenData - TheLen , 64 ) ;
		mySHA256_SubHASH( (DWORD *)Data64 , OutInt ) ;
		TheLen -= 64 ;
	}

	if( TheLen < 56 )
	{
		BYTE	LastData64[64] = {0} ;
		for( i = 0 ; i < TheLen ; i++ )
			LastData64[i] = InStr[LenData - TheLen + i] ;
		LastData64[ TheLen ] = 0x80 ;
		LastData64[56] = (BYTE)(LenData >> 53 ) ;
		LastData64[57] = (BYTE)(LenData >> 45 ) ;
		LastData64[58] = (BYTE)(LenData >> 37 ) ;
		LastData64[59] = (BYTE)(LenData >> 29 ) ;
		LastData64[60] = (BYTE)(LenData >> 21 ) ;
		LastData64[61] = (BYTE)(LenData >> 13 ) ;
		LastData64[62] = (BYTE)(LenData >> 5  ) ;
		LastData64[63] = (BYTE)(LenData << 3  ) ;
		mySHA256_SubHASH( (DWORD *)LastData64 , OutInt ) ;
	}
	else
	{
		BYTE	LastData128[128] = {0} ;
		for( i = 0 ; i < TheLen ; i++ )
			LastData128[i] = InStr[LenData - TheLen + i] ;
		LastData128[ TheLen ] = 0x80 ;
		LastData128[120] = (BYTE)(LenData >> 53 ) ;
		LastData128[121] = (BYTE)(LenData >> 45 ) ;
		LastData128[122] = (BYTE)(LenData >> 37 ) ;
		LastData128[123] = (BYTE)(LenData >> 29 ) ;
		LastData128[124] = (BYTE)(LenData >> 21 ) ;
		LastData128[125] = (BYTE)(LenData >> 13 ) ;
		LastData128[126] = (BYTE)(LenData >> 5  ) ;
		LastData128[127] = (BYTE)(LenData << 3  ) ;
		mySHA256_SubHASH( (DWORD *)LastData128		, OutInt ) ;
		mySHA256_SubHASH( (DWORD *)LastData128 + 16 , OutInt ) ;
	}

	return;
}

void mySHA256_RunStr( BYTE *InStr , unsigned _int64 LenData ,  char OutPutStr[64] )
{
	DWORD OutInt[8] ;
	mySHA256_Run(InStr,LenData,OutInt) ;
	for( BYTE i = 0 ; i < 8 ; i++ )
	{
		itoa( OutInt[i] >> 28 & 0xf , OutPutStr + i * 8 , 16 ) ;
		itoa( OutInt[i] >> 24 & 0xf , OutPutStr + i * 8 + 1 , 16 ) ;
		itoa( OutInt[i] >> 20 & 0xf , OutPutStr + i * 8 + 2 , 16 ) ;
		itoa( OutInt[i] >> 16 & 0xf , OutPutStr + i * 8 + 3 , 16 ) ;
		itoa( OutInt[i] >> 12 & 0xf , OutPutStr + i * 8 + 4 , 16 ) ;
		itoa( OutInt[i] >>  8 & 0xf , OutPutStr + i * 8 + 5 , 16 ) ;
		itoa( OutInt[i] >>  4 & 0xf , OutPutStr + i * 8 + 6 , 16 ) ;
		itoa( OutInt[i]		  & 0xf , OutPutStr + i * 8 + 7 , 16 ) ;
	}
	return ;
}