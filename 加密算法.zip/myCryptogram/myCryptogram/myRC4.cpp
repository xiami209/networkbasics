#include "MyCryptogramHead.h"

#define	myRC4_swap(a,b)			{												\
											c = a ;								\
											a = b ;								\
											b = c ;								\
								}

void	myRC4_encrypt		( BYTE * M , DWORD LenOfM , BYTE * Key , DWORD LenOfKey , BYTE * C )  
{
	BYTE	S[256] = {0} , c(0) ;
	DWORD	i(0) , j(0) , r(0) , t(0) ;

	for( i = 0 ; i < 256 ; i++ )
	{
		S[i] = (BYTE)i ;
	}

	for( i = 0 , j = 0 ; i < 256 ; i++ )
	{
		j = ( j + S[i] + Key[i % LenOfKey] ) & 0xff ;
		myRC4_swap(S[i],S[j]) ;
	}

	for( r = 0 , i = 0 , j = 0 , t = 0 ; r < LenOfM ; r++ )
	{
		i = ( i + 1 ) & 0xff ;
		j = ( j + S[i] ) & 0xff ;
		myRC4_swap(S[i],S[j]) ;
		t = ( S[i] + S[j] ) & 0xff ;
		C[r] = M[r] ^ S[t] ;
	}
	return ;
}

void	myRC4_decrypt		( BYTE * C , DWORD LenOfC , BYTE * Key , DWORD LenOfKey , BYTE * M )  
{
	myRC4_encrypt( C , LenOfC , Key , LenOfKey , M ) ;
	return ;
}