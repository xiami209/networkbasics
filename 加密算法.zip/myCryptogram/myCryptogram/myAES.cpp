
#include "MyCryptogramHead.h"

#define	MinPoly	0x0000011b
#define AddRoundKey(num)		{																\
									NowState[0].data32 ^= RoundKey[(num) * 4 + 0].data32 ;		\
									NowState[1].data32 ^= RoundKey[(num) * 4 + 1].data32 ;		\
									NowState[2].data32 ^= RoundKey[(num) * 4 + 2].data32 ;		\
									NowState[3].data32 ^= RoundKey[(num) * 4 + 3].data32 ;		\
								}
#define DWORD4TORState4(a,b)	{									\
									b[0].data32	=	a[0] ;			\
									b[1].data32	=	a[1] ;			\
									b[2].data32	=	a[2] ;			\
									b[3].data32	=	a[3] ;			\
								}
#define BYTE16TORState4(a,b)	{											\
									b[0].data32 =	( (DWORD *)a )[0] ;		\
									b[1].data32 =	( (DWORD *)a )[1] ;		\
									b[2].data32 =	( (DWORD *)a )[2] ;		\
									b[3].data32 =	( (DWORD *)a )[3] ;		\
								}

#define RState4TOBYTE16(a,b)	{											\
									((DWORD *)b)[0]	=	a[0].data32 ;		\
									((DWORD *)b)[1]	=	a[1].data32 ;		\
									((DWORD *)b)[2]	=	a[2].data32 ;		\
									((DWORD *)b)[3]	=	a[3].data32 ;		\
								}

myAES128::~myAES128()
{
	memset( Key16 , 0xff , 16 ) ;
	for( int i = 0 ; i < 4 ; i++ )
	{
		memset( NowState[i].data8 , 0xff , 4 ) ;
		memset( RoundKey[i].data8 , 0xff , 4 ) ;
	}
	for( ; i < 4 ; i++ )
	{
		memset( RoundKey[i].data8 , 0xff , 4 ) ;
	}
}

BYTE	myAES128::SubByte[256]  = 
{
		  99, 124, 119, 123, 242, 107, 111, 197,  48,   1, 103,  43, 254, 215, 171, 118,
		 202, 130, 201, 125, 250,  89,  71, 240, 173, 212, 162, 175, 156, 164, 114, 192,
		 183, 253, 147,  38,  54,  63, 247, 204,  52, 165, 229, 241, 113, 216,  49,  21,
		   4, 199,  35, 195,  24, 150,   5, 154,   7,  18, 128, 226, 235,  39, 178, 117,
		   9, 131,  44,  26,  27, 110,  90, 160,  82,  59, 214, 179,  41, 227,  47, 132,
		  83, 209,   0, 237,  32, 252, 177,  91, 106, 203, 190,  57,  74,  76,  88, 207,
		 208, 239, 170, 251,  67,  77,  51, 133,  69, 249,   2, 127,  80,  60, 159, 168,
		  81, 163,  64, 143, 146, 157,  56, 245, 188, 182, 218,  33,  16, 255, 243, 210,
		 205,  12,  19, 236,  95, 151,  68,  23, 196, 167, 126,  61, 100,  93,  25, 115,
		  96, 129,  79, 220,  34,  42, 144, 136,  70, 238, 184,  20, 222,  94,  11, 219,
		 224,  50,  58,  10,  73,   6,  36,  92, 194, 211, 172,  98, 145, 149, 228, 121,
		 231, 200,  55, 109, 141, 213,  78, 169, 108,  86, 244, 234, 101, 122, 174,   8,
		 186, 120,  37,  46,  28, 166, 180, 198, 232, 221, 116,  31,  75, 189, 139, 138,
		 112,  62, 181, 102,  72,   3, 246,  14,  97,  53,  87, 185, 134, 193,  29, 158,
		 225, 248, 152,  17, 105, 217, 142, 148, 155,  30, 135, 233, 206,  85,  40, 223,
		 140, 161, 137,  13, 191, 230,  66, 104,  65, 153,  45,  15, 176,  84, 187,  22
} ;

BYTE	myAES128::InvSubByte[256]  = 
{
		  82,   9, 106, 213,  48,  54, 165,  56, 191,  64, 163, 158, 129, 243, 215, 251,
		 124, 227,  57, 130, 155,  47, 255, 135,  52, 142,  67,  68, 196, 222, 233, 203,
		  84, 123, 148,  50, 166, 194,  35,  61, 238,  76, 149,  11,  66, 250, 195,  78,
		   8,  46, 161, 102,  40, 217,  36, 178, 118,  91, 162,  73, 109, 139, 209,  37,
		 114, 248, 246, 100, 134, 104, 152,  22, 212, 164,  92, 204,  93, 101, 182, 146,
		 108, 112,  72,  80, 253, 237, 185, 218,  94,  21,  70,  87, 167, 141, 157, 132,
		 144, 216, 171,   0, 140, 188, 211,  10, 247, 228,  88,   5, 184, 179,  69,   6,
		 208,  44,  30, 143, 202,  63,  15,   2, 193, 175, 189,   3,   1,  19, 138, 107,
		  58, 145,  17,  65,  79, 103, 220, 234, 151, 242, 207, 206, 240, 180, 230, 115,
		 150, 172, 116,  34, 231, 173,  53, 133, 226, 249,  55, 232,  28, 117, 223, 110,
		  71, 241,  26, 113,  29,  41, 197, 137, 111, 183,  98,  14, 170,  24, 190,  27,
		 252,  86,  62,  75, 198, 210, 121,  32, 154, 219, 192, 254, 120, 205,  90, 244,
		  31, 221, 168,  51, 136,   7, 199,  49, 177,  18,  16,  89,  39, 128, 236,  95,
		  96,  81, 127, 169,  25, 181,  74,  13,  45, 229, 122, 159, 147, 201, 156, 239,
		 160, 224,  59,  77, 174,  42, 245, 176, 200, 235, 187,  60, 131,  83, 153,  97,
		  23,  43,   4, 126, 186, 119, 214,  38, 225, 105,  20,  99,  85,  33,  12, 125
} ;

DWORD	myAES128::Rcon[11]  = 
{
		0x0 , 0x00000001 , 0x00000002 , 0x00000004 , 0x00000008 , 0x00000010 ,
			  0x00000020 , 0x00000040 , 0x00000080 , 0x0000001b , 0x00000036 
} ;

void	myAES128::KeyExpansion()
{
	DWORD	i(0) ;
	RoundKey[0].data32	=	((DWORD *)Key16)[0] ;
	RoundKey[1].data32	=	((DWORD *)Key16)[1] ;
	RoundKey[2].data32	=	((DWORD *)Key16)[2] ;
	RoundKey[3].data32	=	((DWORD *)Key16)[3] ;

	for( i = 4 ; i < 44 ; i++ )
	{
		if( (i & 0x00000003) == 0 )
		{
			RoundKey[i].data8[0]	=	SubByte[ RoundKey[i - 1].data8[1] ] ;
			RoundKey[i].data8[1]	=	SubByte[ RoundKey[i - 1].data8[2] ] ;
			RoundKey[i].data8[2]	=	SubByte[ RoundKey[i - 1].data8[3] ] ;
			RoundKey[i].data8[3]	=	SubByte[ RoundKey[i - 1].data8[0] ] ;
			RoundKey[i].data32		^=	Rcon[i >> 2] ;
		}
		else
		{
			RoundKey[i].data32 =	RoundKey[i - 1].data32 ;
		}
		RoundKey[i].data32	^=	RoundKey[i - 4].data32 ;
	}
	return ;
}

void	myAES128::SetNewKey( BYTE PutInKey[16] ) 
{
	memcpy( Key16 , PutInKey , 16 ) ;
	KeyExpansion() ;
}

BYTE	myAES128::FieldMult( BYTE	a	, BYTE	b )
{
	DWORD	c(0) , n(0) ;
	//ģ2�˷�����
	for( n = 0 ; n < 8 ; n++ )
	{
		if( a & ( 1 << n ) )
			c	^=	( (DWORD)b << n ) ;
	}
	//ģȥ��С����ʽ
	for( n = 15 ; n >= 8 ; n-- )
	{
		if( c & ( 1 << n ) )
			c	^=	( MinPoly << ( n - 8 ) ) ;
	}
	return ( (BYTE)c ) ;
}

void	myAES128::IniMixTable()
{
	BYTE	mid[4]	=	{ 0x02 , 0x01 , 0x01 , 0x03 } ,
			Invmid[4]	=	{ 0x0e , 0x09 , 0x0d , 0x0b } ;
	int		i(0) , j(0) ;
	for( i = 0 ; i < 256 ; i++ )
	{
		for( j = 0 ; j < 4 ; j++ )
		{
			Mixcolumn1[i].data8[j] = FieldMult( mid[j] , i ) ;
			Mixcolumn2[i].data8[j] = FieldMult( mid[( j + 3 ) & 0x03 ] , i ) ;
			Mixcolumn3[i].data8[j] = FieldMult( mid[( j + 2 ) & 0x03 ] , i ) ;
			Mixcolumn4[i].data8[j] = FieldMult( mid[( j + 1 ) & 0x03 ] , i ) ;

			InvMixcolumn1[i].data8[j] = FieldMult( Invmid[j] , i ) ;
			InvMixcolumn2[i].data8[j] = FieldMult( Invmid[( j + 3 ) & 0x03 ] , i ) ;
			InvMixcolumn3[i].data8[j] = FieldMult( Invmid[( j + 2 ) & 0x03 ] , i ) ;
			InvMixcolumn4[i].data8[j] = FieldMult( Invmid[( j + 1 ) & 0x03 ] , i ) ;
		}
	}
}

void	myAES128::Encrypt16( BYTE data[16] , BYTE code[16] )
{
	BYTE16TORState4(data,NowState) ;

	DWORD	temp[4] ;
	int		i(0) , j(0) ;
	AddRoundKey(0) ;
	for( i = 1 ; i < 10 ; i++ )
	{
		temp[0]	=	Mixcolumn1[SubByte[NowState[0].data8[0]]].data32 
			^ Mixcolumn2[SubByte[NowState[1].data8[1]]].data32 
			^ Mixcolumn3[SubByte[NowState[2].data8[2]]].data32 
			^ Mixcolumn4[SubByte[NowState[3].data8[3]]].data32 ;
		temp[1]	=	Mixcolumn1[SubByte[NowState[1].data8[0]]].data32 
			^ Mixcolumn2[SubByte[NowState[2].data8[1]]].data32 
			^ Mixcolumn3[SubByte[NowState[3].data8[2]]].data32 
			^ Mixcolumn4[SubByte[NowState[0].data8[3]]].data32 ;
		temp[2]	=	Mixcolumn1[SubByte[NowState[2].data8[0]]].data32 
			^ Mixcolumn2[SubByte[NowState[3].data8[1]]].data32 
			^ Mixcolumn3[SubByte[NowState[0].data8[2]]].data32 
			^ Mixcolumn4[SubByte[NowState[1].data8[3]]].data32 ;
		temp[3]	=	Mixcolumn1[SubByte[NowState[3].data8[0]]].data32 
			^ Mixcolumn2[SubByte[NowState[0].data8[1]]].data32 
			^ Mixcolumn3[SubByte[NowState[1].data8[2]]].data32 
			^ Mixcolumn4[SubByte[NowState[2].data8[3]]].data32 ;
		DWORD4TORState4(temp,NowState) ;
		AddRoundKey(i) ;
	}

	for( i = 0 ; i < 4 ; i++ )
		for( j = 0 ; j < 4 ; j++ )
			((BYTE *)temp)[i * 4 + j]	=	SubByte[NowState[(i + j) & 0x03].data8[j]] ;
	DWORD4TORState4(temp,NowState) ;
	AddRoundKey(10) ;

	RState4TOBYTE16(NowState,code) ;
}

void	myAES128::Decrypt16( BYTE code[16] , BYTE data[16] ) 
{
	DWORD	temp[4] ;
	int		i(0) , j(0) , k(0) ;
	BYTE16TORState4(code,NowState) ;

	AddRoundKey(10) ;

	for( i = 0 ; i < 4 ; i++ )
		for( j = 0 ; j < 4 ; j++ )
			((BYTE *)temp)[i * 4 + j]	=	InvSubByte[NowState[(i - j + 4) & 0x03].data8[j]] ;
	DWORD4TORState4(temp,NowState) ;
	
	for( k = 9 ; k > 0 ; k-- )
	{
		AddRoundKey(k) ;
		temp[0]	=	InvMixcolumn1[NowState[0].data8[0]].data32 
			^ InvMixcolumn2[NowState[0].data8[1]].data32 
			^ InvMixcolumn3[NowState[0].data8[2]].data32 
			^ InvMixcolumn4[NowState[0].data8[3]].data32 ;
		temp[1]	=	InvMixcolumn1[NowState[1].data8[0]].data32 
			^ InvMixcolumn2[NowState[1].data8[1]].data32 
			^ InvMixcolumn3[NowState[1].data8[2]].data32 
			^ InvMixcolumn4[NowState[1].data8[3]].data32 ;
		temp[2]	=	InvMixcolumn1[NowState[2].data8[0]].data32 
			^ InvMixcolumn2[NowState[2].data8[1]].data32 
			^ InvMixcolumn3[NowState[2].data8[2]].data32 
			^ InvMixcolumn4[NowState[2].data8[3]].data32 ;
		temp[3]	=	InvMixcolumn1[NowState[3].data8[0]].data32 
			^ InvMixcolumn2[NowState[3].data8[1]].data32 
			^ InvMixcolumn3[NowState[3].data8[2]].data32 
			^ InvMixcolumn4[NowState[3].data8[3]].data32 ;
		DWORD4TORState4(temp,NowState) ;

		for( i = 0 ; i < 4 ; i++ )
			for( j = 0 ; j < 4 ; j++ )
				((BYTE *)temp)[i * 4 + j]	=	InvSubByte[NowState[(i - j + 4) & 0x03].data8[j]] ;
		DWORD4TORState4(temp,NowState) ;
	}
	AddRoundKey(0) ;

	RState4TOBYTE16(NowState,data) ;
}

DWORD	myAES128::EncryptX( BYTE * data , DWORD LenOfData , BYTE * code ) 
{
	DWORD	i(0) ;
	if( LenOfData == 0 )
		return 0 ;
	for( i = 0 ; i + 16 <= LenOfData ; i += 16 )
		Encrypt16( data + i , code + i ) ;
	if( LenOfData & 0x0000000f )
	{
		BYTE	LastData[16] = {0} ;
		memcpy( LastData , data + i , LenOfData & 0x0000000f ) ;
		Encrypt16( LastData , code + i ) ;
	}
	return ( i + 16 );
}

DWORD	myAES128::DecryptX( BYTE * code , DWORD LenOfCode , BYTE * data ) 
{
	if( ( LenOfCode & 0x0000000f ) || ( LenOfCode == 0 ) )
		return 0 ;
	DWORD	i(0) ;
	for( i = 0 ; i + 16 <= LenOfCode ; i += 16 )
		Decrypt16( code + i , data + i ) ;

	return LenOfCode ;
}

DWORD	myAES128::EncryptFile( char * FilePath , BYTE * code ) 
{
	FILE	* fp ;
	if( (fp = fopen( FilePath , "rb" )) == NULL )						
		return (~0) ;

	DWORD	LenOfData , LenOfCode ;
	fseek( fp , 0 , SEEK_END );											
	LenOfData = ftell( fp ) ;
	rewind( fp ) ;
	BYTE	* data ;
	data	=	new BYTE[LenOfData] ;
	fread( data , LenOfData , 1 , fp ) ;
	LenOfCode = EncryptX( data , LenOfData , code ) ;
	delete data ;
	fclose( fp ) ;
	return ( LenOfCode ) ;
}

DWORD	myAES128::DecryptFile( char * FilePath , BYTE * data ) 
{
	FILE	* fp ;
	if( (fp = fopen( FilePath , "rb" )) == NULL )						
		return (~0) ;

	DWORD	LenOfData , LenOfCode ;
	fseek( fp , 0 , SEEK_END );											
	LenOfCode = ftell( fp ) ;
	rewind( fp ) ;
	BYTE	* code ;
	code	=	new BYTE[LenOfCode] ;
	fread( code , LenOfCode , 1 , fp ) ;
	LenOfData = DecryptX( code , LenOfCode , data ) ;
	delete code ;
	fclose( fp ) ;
	return ( LenOfData ) ;
}

void	myAES128::GetNowKey( BYTE PutOutKey[16] ) 
{
	memcpy( PutOutKey , Key16 , 16 ) ;
	return ;
}
