#include "MyCryptogramHead.h"


void myRIPEMD256_SubHASH(DWORD InputData[16],DWORD HashValue[8])
{
#define SRL32(x,n) (((x)<<n)|((x)>>(32-n)))
//128-320��Ҫ��5�۱任
#define md_F(x, y, z)    (x ^ y ^ z) 
#define md_G(x, y, z)    (z ^ (x & (y^z)))
#define md_H(x, y, z)    (z ^ (x | ~y))
#define md_I(x, y, z)    (y ^ (z & (x^y)))
#define md_J(x, y, z)    (x ^ (y | ~z))
//����
#define md_k0 0
#define md_k1 0x5a827999UL
#define md_k2 0x6ed9eba1UL
#define md_k3 0x8f1bbcdcUL
#define md_k4 0xa953fd4eUL
#define md_k5 0x50a28be6UL
#define md_k6 0x5c4dd124UL
#define md_k7 0x6d703ef3UL
#define md_k8 0x7a6d76e9UL
#define md_k9 0  
// for 160 and 320
#define md_Subround(f, a, b, c, d, e, x, s, md_k)        \
 a += f(b, c, d) + x + md_k;\
 a = SRL32((DWORD)a, s) + e;\
 c = SRL32((DWORD)c, 10U)
// for 128 and 256
#define md1_Subround(f, a, b, c, d, x, s, md_k)        \
 a += f(b, c, d) + x + md_k;\
 a = SRL32((DWORD)a, s);


	DWORD a1, b1, c1, d1, a2, b2, c2, d2, t;
	a1 = HashValue[0];
	b1 = HashValue[1];
	c1 = HashValue[2];
	d1 = HashValue[3];
	a2 = HashValue[4];
	b2 = HashValue[5];
	c2 = HashValue[6];
	d2 = HashValue[7];

	md1_Subround(md_F, a1, b1, c1, d1, InputData[ 0], 11, md_k0);
	md1_Subround(md_F, d1, a1, b1, c1, InputData[ 1], 14, md_k0);
	md1_Subround(md_F, c1, d1, a1, b1, InputData[ 2], 15, md_k0);
	md1_Subround(md_F, b1, c1, d1, a1, InputData[ 3], 12, md_k0);
	md1_Subround(md_F, a1, b1, c1, d1, InputData[ 4],  5, md_k0);
	md1_Subround(md_F, d1, a1, b1, c1, InputData[ 5],  8, md_k0);
	md1_Subround(md_F, c1, d1, a1, b1, InputData[ 6],  7, md_k0);
	md1_Subround(md_F, b1, c1, d1, a1, InputData[ 7],  9, md_k0);
	md1_Subround(md_F, a1, b1, c1, d1, InputData[ 8], 11, md_k0);
	md1_Subround(md_F, d1, a1, b1, c1, InputData[ 9], 13, md_k0);
	md1_Subround(md_F, c1, d1, a1, b1, InputData[10], 14, md_k0);
	md1_Subround(md_F, b1, c1, d1, a1, InputData[11], 15, md_k0);
	md1_Subround(md_F, a1, b1, c1, d1, InputData[12],  6, md_k0);
	md1_Subround(md_F, d1, a1, b1, c1, InputData[13],  7, md_k0);
	md1_Subround(md_F, c1, d1, a1, b1, InputData[14],  9, md_k0);
	md1_Subround(md_F, b1, c1, d1, a1, InputData[15],  8, md_k0);

	md1_Subround(md_I, a2, b2, c2, d2, InputData[ 5],  8, md_k5);
	md1_Subround(md_I, d2, a2, b2, c2, InputData[14],  9, md_k5);
	md1_Subround(md_I, c2, d2, a2, b2, InputData[ 7],  9, md_k5);
	md1_Subround(md_I, b2, c2, d2, a2, InputData[ 0], 11, md_k5);
	md1_Subround(md_I, a2, b2, c2, d2, InputData[ 9], 13, md_k5);
	md1_Subround(md_I, d2, a2, b2, c2, InputData[ 2], 15, md_k5);
	md1_Subround(md_I, c2, d2, a2, b2, InputData[11], 15, md_k5);
	md1_Subround(md_I, b2, c2, d2, a2, InputData[ 4],  5, md_k5);
	md1_Subround(md_I, a2, b2, c2, d2, InputData[13],  7, md_k5);
	md1_Subround(md_I, d2, a2, b2, c2, InputData[ 6],  7, md_k5);
	md1_Subround(md_I, c2, d2, a2, b2, InputData[15],  8, md_k5);
	md1_Subround(md_I, b2, c2, d2, a2, InputData[ 8], 11, md_k5);
	md1_Subround(md_I, a2, b2, c2, d2, InputData[ 1], 14, md_k5);
	md1_Subround(md_I, d2, a2, b2, c2, InputData[10], 14, md_k5);
	md1_Subround(md_I, c2, d2, a2, b2, InputData[ 3], 12, md_k5);
	md1_Subround(md_I, b2, c2, d2, a2, InputData[12],  6, md_k5);

	t = a1; a1 = a2; a2 = t;

	md1_Subround(md_G, a1, b1, c1, d1, InputData[ 7],  7, md_k1);
	md1_Subround(md_G, d1, a1, b1, c1, InputData[ 4],  6, md_k1);
	md1_Subround(md_G, c1, d1, a1, b1, InputData[13],  8, md_k1);
	md1_Subround(md_G, b1, c1, d1, a1, InputData[ 1], 13, md_k1);
	md1_Subround(md_G, a1, b1, c1, d1, InputData[10], 11, md_k1);
	md1_Subround(md_G, d1, a1, b1, c1, InputData[ 6],  9, md_k1);
	md1_Subround(md_G, c1, d1, a1, b1, InputData[15],  7, md_k1);
	md1_Subround(md_G, b1, c1, d1, a1, InputData[ 3], 15, md_k1);
	md1_Subround(md_G, a1, b1, c1, d1, InputData[12],  7, md_k1);
	md1_Subround(md_G, d1, a1, b1, c1, InputData[ 0], 12, md_k1);
	md1_Subround(md_G, c1, d1, a1, b1, InputData[ 9], 15, md_k1);
	md1_Subround(md_G, b1, c1, d1, a1, InputData[ 5],  9, md_k1);
	md1_Subround(md_G, a1, b1, c1, d1, InputData[ 2], 11, md_k1);
	md1_Subround(md_G, d1, a1, b1, c1, InputData[14],  7, md_k1);
	md1_Subround(md_G, c1, d1, a1, b1, InputData[11], 13, md_k1);
	md1_Subround(md_G, b1, c1, d1, a1, InputData[ 8], 12, md_k1);

	md1_Subround(md_H, a2, b2, c2, d2, InputData[ 6],  9, md_k6);
	md1_Subround(md_H, d2, a2, b2, c2, InputData[11], 13, md_k6);
	md1_Subround(md_H, c2, d2, a2, b2, InputData[ 3], 15, md_k6);
	md1_Subround(md_H, b2, c2, d2, a2, InputData[ 7],  7, md_k6);
	md1_Subround(md_H, a2, b2, c2, d2, InputData[ 0], 12, md_k6);
	md1_Subround(md_H, d2, a2, b2, c2, InputData[13],  8, md_k6);
	md1_Subround(md_H, c2, d2, a2, b2, InputData[ 5],  9, md_k6);
	md1_Subround(md_H, b2, c2, d2, a2, InputData[10], 11, md_k6);
	md1_Subround(md_H, a2, b2, c2, d2, InputData[14],  7, md_k6);
	md1_Subround(md_H, d2, a2, b2, c2, InputData[15],  7, md_k6);
	md1_Subround(md_H, c2, d2, a2, b2, InputData[ 8], 12, md_k6);
	md1_Subround(md_H, b2, c2, d2, a2, InputData[12],  7, md_k6);
	md1_Subround(md_H, a2, b2, c2, d2, InputData[ 4],  6, md_k6);
	md1_Subround(md_H, d2, a2, b2, c2, InputData[ 9], 15, md_k6);
	md1_Subround(md_H, c2, d2, a2, b2, InputData[ 1], 13, md_k6);
	md1_Subround(md_H, b2, c2, d2, a2, InputData[ 2], 11, md_k6);

	t = b1; b1 = b2; b2 = t;

	md1_Subround(md_H, a1, b1, c1, d1, InputData[ 3], 11, md_k2);
	md1_Subround(md_H, d1, a1, b1, c1, InputData[10], 13, md_k2);
	md1_Subround(md_H, c1, d1, a1, b1, InputData[14],  6, md_k2);
	md1_Subround(md_H, b1, c1, d1, a1, InputData[ 4],  7, md_k2);
	md1_Subround(md_H, a1, b1, c1, d1, InputData[ 9], 14, md_k2);
	md1_Subround(md_H, d1, a1, b1, c1, InputData[15],  9, md_k2);
	md1_Subround(md_H, c1, d1, a1, b1, InputData[ 8], 13, md_k2);
	md1_Subround(md_H, b1, c1, d1, a1, InputData[ 1], 15, md_k2);
	md1_Subround(md_H, a1, b1, c1, d1, InputData[ 2], 14, md_k2);
	md1_Subround(md_H, d1, a1, b1, c1, InputData[ 7],  8, md_k2);
	md1_Subround(md_H, c1, d1, a1, b1, InputData[ 0], 13, md_k2);
	md1_Subround(md_H, b1, c1, d1, a1, InputData[ 6],  6, md_k2);
	md1_Subround(md_H, a1, b1, c1, d1, InputData[13],  5, md_k2);
	md1_Subround(md_H, d1, a1, b1, c1, InputData[11], 12, md_k2);
	md1_Subround(md_H, c1, d1, a1, b1, InputData[ 5],  7, md_k2);
	md1_Subround(md_H, b1, c1, d1, a1, InputData[12],  5, md_k2);

	md1_Subround(md_G, a2, b2, c2, d2, InputData[15],  9, md_k7);
	md1_Subround(md_G, d2, a2, b2, c2, InputData[ 5],  7, md_k7);
	md1_Subround(md_G, c2, d2, a2, b2, InputData[ 1], 15, md_k7);
	md1_Subround(md_G, b2, c2, d2, a2, InputData[ 3], 11, md_k7);
	md1_Subround(md_G, a2, b2, c2, d2, InputData[ 7],  8, md_k7);
	md1_Subround(md_G, d2, a2, b2, c2, InputData[14],  6, md_k7);
	md1_Subround(md_G, c2, d2, a2, b2, InputData[ 6],  6, md_k7);
	md1_Subround(md_G, b2, c2, d2, a2, InputData[ 9], 14, md_k7);
	md1_Subround(md_G, a2, b2, c2, d2, InputData[11], 12, md_k7);
	md1_Subround(md_G, d2, a2, b2, c2, InputData[ 8], 13, md_k7);
	md1_Subround(md_G, c2, d2, a2, b2, InputData[12],  5, md_k7);
	md1_Subround(md_G, b2, c2, d2, a2, InputData[ 2], 14, md_k7);
	md1_Subround(md_G, a2, b2, c2, d2, InputData[10], 13, md_k7);
	md1_Subround(md_G, d2, a2, b2, c2, InputData[ 0], 13, md_k7);
	md1_Subround(md_G, c2, d2, a2, b2, InputData[ 4],  7, md_k7);
	md1_Subround(md_G, b2, c2, d2, a2, InputData[13],  5, md_k7);

	t = c1; c1 = c2; c2 = t;

	md1_Subround(md_I, a1, b1, c1, d1, InputData[ 1], 11, md_k3);
	md1_Subround(md_I, d1, a1, b1, c1, InputData[ 9], 12, md_k3);
	md1_Subround(md_I, c1, d1, a1, b1, InputData[11], 14, md_k3);
	md1_Subround(md_I, b1, c1, d1, a1, InputData[10], 15, md_k3);
	md1_Subround(md_I, a1, b1, c1, d1, InputData[ 0], 14, md_k3);
	md1_Subround(md_I, d1, a1, b1, c1, InputData[ 8], 15, md_k3);
	md1_Subround(md_I, c1, d1, a1, b1, InputData[12],  9, md_k3);
	md1_Subround(md_I, b1, c1, d1, a1, InputData[ 4],  8, md_k3);
	md1_Subround(md_I, a1, b1, c1, d1, InputData[13],  9, md_k3);
	md1_Subround(md_I, d1, a1, b1, c1, InputData[ 3], 14, md_k3);
	md1_Subround(md_I, c1, d1, a1, b1, InputData[ 7],  5, md_k3);
	md1_Subround(md_I, b1, c1, d1, a1, InputData[15],  6, md_k3);
	md1_Subround(md_I, a1, b1, c1, d1, InputData[14],  8, md_k3);
	md1_Subround(md_I, d1, a1, b1, c1, InputData[ 5],  6, md_k3);
	md1_Subround(md_I, c1, d1, a1, b1, InputData[ 6],  5, md_k3);
	md1_Subround(md_I, b1, c1, d1, a1, InputData[ 2], 12, md_k3);

	md1_Subround(md_F, a2, b2, c2, d2, InputData[ 8], 15, md_k9);
	md1_Subround(md_F, d2, a2, b2, c2, InputData[ 6],  5, md_k9);
	md1_Subround(md_F, c2, d2, a2, b2, InputData[ 4],  8, md_k9);
	md1_Subround(md_F, b2, c2, d2, a2, InputData[ 1], 11, md_k9);
	md1_Subround(md_F, a2, b2, c2, d2, InputData[ 3], 14, md_k9);
	md1_Subround(md_F, d2, a2, b2, c2, InputData[11], 14, md_k9);
	md1_Subround(md_F, c2, d2, a2, b2, InputData[15],  6, md_k9);
	md1_Subround(md_F, b2, c2, d2, a2, InputData[ 0], 14, md_k9);
	md1_Subround(md_F, a2, b2, c2, d2, InputData[ 5],  6, md_k9);
	md1_Subround(md_F, d2, a2, b2, c2, InputData[12],  9, md_k9);
	md1_Subround(md_F, c2, d2, a2, b2, InputData[ 2], 12, md_k9);
	md1_Subround(md_F, b2, c2, d2, a2, InputData[13],  9, md_k9);
	md1_Subround(md_F, a2, b2, c2, d2, InputData[ 9], 12, md_k9);
	md1_Subround(md_F, d2, a2, b2, c2, InputData[ 7],  5, md_k9);
	md1_Subround(md_F, c2, d2, a2, b2, InputData[10], 15, md_k9);
	md1_Subround(md_F, b2, c2, d2, a2, InputData[14],  8, md_k9);

	t = d1; d1 = d2; d2 = t;

	HashValue[0] += a1;
	HashValue[1] += b1;
	HashValue[2] += c1;
	HashValue[3] += d1;
	HashValue[4] += a2;
	HashValue[5] += b2;
	HashValue[6] += c2;
	HashValue[7] += d2;
}

void myRIPEMD256_Run( BYTE *InStr , unsigned _int64 LenData ,  DWORD OutInt[8] )
{
	OutInt[0] = 0x67452301L;
	OutInt[1] = 0xefcdab89L;
	OutInt[2] = 0x98badcfeL;
	OutInt[3] = 0x10325476L;
	OutInt[4] = 0x76543210L;
	OutInt[5] = 0xfedcba98L;
	OutInt[6] = 0x89abcdefL;
	OutInt[7] = 0x01234567L;

	unsigned _int64	TheLen( LenData ) , i(0) ;
	BYTE	Data64[64] = {0} ;

	while( TheLen >= 64 )
	{
		memcpy( Data64 , InStr + LenData - TheLen , 64 ) ;
		myRIPEMD256_SubHASH( (DWORD *)Data64 , OutInt ) ;
		TheLen -= 64 ;
	}

	if( TheLen < 56 )
	{
		BYTE	LastData64[64] = {0} ;
		for( i = 0 ; i < TheLen ; i++ )
			LastData64[i] = InStr[LenData - TheLen + i] ;
		LastData64[ TheLen ] = 0x80 ;
		((unsigned _int64 *)LastData64)[7] = ( LenData << 3 ) ;
		myRIPEMD256_SubHASH( (DWORD *)LastData64 , OutInt ) ;
	}
	else
	{
		BYTE	LastData128[128] = {0} ;
		for( i = 0 ; i < TheLen ; i++ )
			LastData128[i] = InStr[LenData - TheLen + i] ;
		LastData128[ TheLen ] = 0x80 ;
		((unsigned _int64 *)LastData128)[15] = ( LenData << 3 ) ;
		myRIPEMD256_SubHASH( (DWORD *)LastData128		, OutInt ) ;
		myRIPEMD256_SubHASH( (DWORD *)LastData128 + 16 , OutInt ) ;
	}

	return;
}

void myRIPEMD256_RunStr( BYTE *InStr , unsigned _int64 LenData ,  char OutPutStr[64] )
{
	DWORD OutInt[8] ;
	myRIPEMD256_Run(InStr,LenData,OutInt) ;
	for( BYTE i = 0 ; i < 32 ; i++ )
	{
		itoa( ((BYTE *)OutInt)[i] >> 4  , OutPutStr + i * 2 , 16 ) ;
		itoa( ((BYTE *)OutInt)[i] & 0xf , OutPutStr + i * 2 + 1 , 16 ) ;
	}
	return ;
}